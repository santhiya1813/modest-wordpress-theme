<?php
function modest_theme_assets() {

    // Bootstrap CSS
    wp_enqueue_style(
        'bootstrap-css',
        'https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css'
    );

    // Font Awesome
    wp_enqueue_style(
        'fontawesome-css',
        'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css'
    );

    // Theme main style.css (must be LAST)
    wp_enqueue_style(
        'modest-style',
        get_stylesheet_uri(),
        array('bootstrap-css'),
        filemtime(get_stylesheet_directory() . '/style.css')
    );

    // Bootstrap JS
    wp_enqueue_script(
        'bootstrap-js',
        'https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js',
        array(),
        null,
        true
    );

    // Custom JS
    wp_enqueue_script(
        'modest-js',
        get_template_directory_uri() . '/assets/js/main.js',
        array('bootstrap-js'),
        null,
        true
    );
}

add_action('wp_enqueue_scripts', 'modest_theme_assets');
