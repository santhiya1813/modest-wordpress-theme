<?php get_header(); ?>
 
 <!-- ================= HERO SECTION ================= -->
    <section class="hero-section d-flex align-items-center">
        <div class="container text-white">
            <h1>WELCOME TO OUR MARKETPLACE</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed nisi metus.</p>
            <div class="mt-4">
                <a href="#" class="btn btn-primary me-2">View More</a>
                <a href="#" class="btn btn-outline-light">Video Tour</a>
            </div>
        </div>
    </section>

    <!-- ================= ABOUT SECTION ================= -->
    <section id="about" class="section-padding">
        <div class="container">
            <div class="row">
                <h2 style="color: black;" class="heading">
                    <span class="vertical-bar"></span>
                    WE ARE MODEST.
                </h2>
                <div class="col-lg-6" style="color:#6f7880;">
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed nisi metus, tristique ndolor non,
                        ornare sagittis dolor. Nulla vestibulu lacus sed molestie gravida. Crferm entum quismagna
                        congue, vel sodales arcu vestibulum. Nunc lobortis dui magna, quis lacusullamcorper at.</p>
                    <p>Phasellus sollicitudin ante eros ornare, sit amet luctus lorem semper. Suspendisse posuere,
                        quamdictum consectetur, augue metus pharetra tellus, eu feugiatloreg egetnisi. Cras ornare
                        bibendum ante, ut bibendum odio convallis eget. vel sodales arcu vestibulum</p>

                    <div class="social-icons mt-3">
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-google-plus-g"></i></a>
                        <a href="#"><i class="fab fa-dribbble"></i></a>
                        <a href="#"><i class="fab fa-behance"></i></a>
                    </div>
                </div>

                <div class="col-lg-6">
                    <div class="feature-box">
                        <span>01</span>
                        <div>
                            <h5>Dedication to the Customers</h5>
                            <p>Integer vel lacus non dui ullamcorper venenatis.</p>
                            <p>Aliquam vitae tristique nisi, vitae ullamcorper risus.</p>
                        </div>
                    </div>

                    <div class="feature-box">
                        <span>02</span>
                        <div>
                            <h5>Working Closely With Our Clients</h5>
                            <p>Sed blandit nisi urna, sed pellentesque enim consectetur vitae. Suspendisse ut vehicula
                                nibh.</p>
                        </div>
                    </div>

                    <div class="feature-box">
                        <span>03</span>
                        <div>
                            <h5>Increase Happiness</h5>
                            <p>Lorem ipsum dolor sit amet, consectetur elit. Nulla eleifend laoreet euismod.</p>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- ================= TEAM SECTION ================= -->
    <section id="team" class="bg-light section-padding">
        <div class="container text-center">
            <h2 style="color: black;" class="heading">
                <span class="vertical-bar"></span>
                MEET THE TEAM.
            </h2>

            <div class="row mt-4">
                <!-- Team Member -->
                <div class="col-md-3">
                    <div class="team-card">
                        <img src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&h=400&fit=crop"
                            class="img-fluid" alt="Gloria Bromley">
                        <div class="team-card-para">
                            <h5>Gloria Bromley</h5>
                            <p>CEO and Founder</p>
                        </div>

                    </div>
                </div>

                <div class="col-md-3">
                    <div class="team-card">
                        <img src="https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=400&h=400&fit=crop"
                            class="img-fluid" alt="Paul Torres">
                        <div class="team-card-para">
                            <h5>Paul Torres</h5>
                            <p>Head of Development</p>
                        </div>

                    </div>
                </div>

                <div class="col-md-3">
                    <div class="team-card">
                        <img src="https://images.unsplash.com/photo-1547425260-76bcadfb4f2c?w=400&h=400&fit=crop"
                            class="img-fluid" alt="Judith Gillette">
                        <div class="team-card-para">
                            <h5>Judith Gillette</h5>
                            <p>Graphic Designer</p>
                        </div>

                    </div>
                </div>

                <div class="col-md-3">
                    <div class="team-card">
                        <img src="https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=400&h=400&fit=crop"
                            class="img-fluid" alt="Delores Reed">
                        <div class="team-card-para">
                            <h5>Delores Reed</h5>
                            <p>Client Service Director</p>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- ================= WORK / PORTFOLIO ================= -->
    <section id="work" class="dark-section section-padding">
        <div class="container text-center text-white">
            <h2 class="heading">
                <span class="vertical-bar"></span>
                LOVELY WORK.
            </h2>

            <div class="row mt-4 g-3">
                <!-- Row 1 -->
                <div class="col-md-4">
                    <div class="work-item">
                        <img src="https://images.unsplash.com/photo-1492724441997-5dc865305da7?w=600" class="img-fluid"
                            alt="Creative Workspace">
                        <div class="work-overlay">Creative Workspace</div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="work-item">
                        <img src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=600" class="img-fluid"
                            alt="Web Development">
                        <div class="work-overlay">Web Development</div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="work-item">
                        <img src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=600" class="img-fluid"
                            alt="Team Collaboration">
                        <div class="work-overlay">Team Collaboration</div>
                    </div>
                </div>

                <!-- Row 2 -->
                <div class="col-md-4">
                    <div class="work-item">
                        <img src="https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=600" class="img-fluid"
                            alt="Mobile App Design">
                        <div class="work-overlay">Mobile App Design</div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="work-item">
                        <img src="https://images.unsplash.com/photo-1487014679447-9f8336841d58?w=600" class="img-fluid"
                            alt="UI UX Design">
                        <div class="work-overlay">UI / UX Design</div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="work-item">
                        <img src="https://images.unsplash.com/photo-1497032628192-86f99bcd76bc?w=600" class="img-fluid"
                            alt="Digital Marketing">
                        <div class="work-overlay">Digital Marketing</div>
                    </div>
                </div>
            </div>

            <a href="#" class="btn btn-outline-light mt-4">Show Me More</a>
        </div>
    </section>


    <!-- ================= SERVICES ================= -->
    <section id="services" class="section-padding">
        <div class="container text-center">
            <h2 class="heading" style="color: black;">
                <span class="vertical-bar"></span>
                WHAT WE DO.
            </h2>

            <div class="row mt-4">
                <div class="col-md-3 service-box">
                    <i class="fas fa-cog"></i>
                    <h6>Easy Theme Setup</h6>
                    <p>Nunc mattis lorem in leo lobortis, ut venenatis justo commodo. Maecenas a justo nec velit egestas
                        fermentum.</p>
                </div>
                <div class="col-md-3 service-box">
                    <i class="fas fa-pen-nib"></i>
                    <h6>Pixel Perfect Design</h6>
                    <p>Nunc mattis lorem in leo lobortis, ut venenatis justo commodo. Maecenas a justo nec velit egestas
                        fermentum.</p>
                </div>
                <div class="col-md-3 service-box">
                    <i class="fas fa-mobile-alt"></i>
                    <h6>Responsive Display</h6>
                    <p>Nunc mattis lorem in leo lobortis, ut venenatis justo commodo. Maecenas a justo nec velit egestas
                        fermentum.</p>
                </div>
                <div class="col-md-3 service-box">
                    <i class="fas fa-clock"></i>
                    <h6>24/7 Support</h6>
                    <p>Nunc mattis lorem in leo lobortis, ut venenatis justo commodo. Maecenas a justo nec velit egestas
                        fermentum.</p>
                </div>
            </div>

            <div class="row mt-4">
                <div class="col-md-3 service-box">
                    <i class="fas fa-cog"></i>
                    <h6>Easy Theme Setup</h6>
                    <p>Nunc mattis lorem in leo lobortis, ut venenatis justo commodo. Maecenas a justo nec velit egestas
                        fermentum.</p>
                </div>
                <div class="col-md-3 service-box">
                    <i class="fas fa-pen-nib"></i>
                    <h6>Pixel Perfect Design</h6>
                    <p>Nunc mattis lorem in leo lobortis, ut venenatis justo commodo. Maecenas a justo nec velit egestas
                        fermentum.</p>
                </div>
                <div class="col-md-3 service-box">
                    <i class="fas fa-mobile-alt"></i>
                    <h6>Responsive Display</h6>
                    <p>Nunc mattis lorem in leo lobortis, ut venenatis justo commodo. Maecenas a justo nec velit egestas
                        fermentum.</p>
                </div>
                <div class="col-md-3 service-box">
                    <i class="fas fa-clock"></i>
                    <h6>24/7 Support</h6>
                    <p>Nunc mattis lorem in leo lobortis, ut venenatis justo commodo. Maecenas a justo nec velit egestas
                        fermentum.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- ================= FEATURES ================= -->

    <section id="features" class="dark-section section-padding">
        <div class="container text-center">
            <h2 class="heading">
                <span class="vertical-bar"></span>
                FEATURES.
            </h2>


            <div class="row mt-4">
                <!-- Feature 1 -->
                <div class="col-md-4">
                    <div class="feature-card">
                        <img src="https://images.unsplash.com/photo-1555041469-a586c61ea9bc?crop=entropy&cs=tinysrgb&fit=crop&h=400&w=400"
                            class="img-fluid" alt="Product Design">
                        <div class="feature-card-para mt-3">
                            <h5>Product Design: Eames Chairs</h5>
                            <p>Innovative and stylish chair designs inspired by Eames, perfect for modern interiors.</p>
                        </div>
                    </div>
                </div>

                <!-- Feature 2 -->
                <div class="col-md-4">
                    <div class="feature-card">
                        <img src="https://images.unsplash.com/photo-1507679799987-c73779587ccf?ixlib=rb-4.0.3&w=400&h=400&fit=crop&q=80"
                            class="img-fluid" alt="Elegant and Colorful Logos">
                        <div class="feature-card-para mt-3">
                            <h5>Elegant and Colorful Logos</h5>
                            <p>Creative and vibrant logo designs that capture the essence of your brand identity.</p>
                        </div>
                    </div>
                </div>

                <!-- Feature 3 -->
                <div class="col-md-4">
                    <div class="feature-card">
                        <img src="https://picsum.photos/id/1037/400/400" class="img-fluid" alt="A Showcase of Creative">
                        <div class="feature-card-para mt-3">
                            <h5>A Showcase of Creative</h5>
                            <p>Exhibiting a collection of imaginative works and artistic projects to inspire everyone.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- ================= CONTACT ================= -->
    <section id="contact" class="bg-light section-padding">
        <div class="container">
              <h2 style="color: black;" class="heading">
                    <span class="vertical-bar"></span>
                    STAY IN TOUCH.
                </h2>

            <!-- Map -->
            <div class="map-wrapper">
                <iframe src="https://maps.google.com/maps?q=Ahmedabad&t=&z=13&ie=UTF8&iwloc=&output=embed" width="100%"
                    height="300" style="border:0;">
                </iframe>
            </div>

            <div class="row mt-4 position-relative">
                <div class="col-md-6">
                    <h5 style="font-weight: bold;">CONTACT INFORMATION</h5>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed nisi metus, tristique nec dolor non,
                        ornare sagittis dolor.</p>
                    <p>Cras fermentum elit quis magna congue, vel sodales arcu vestibulum.</p>
                </div>

                <!-- Form -->
                <div class="col-md-6">
                    <div class="form-box overlap-form">
                        <form>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label>Name</label>
                                    <input type="text" class="form-control">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label>Email</label>
                                    <input type="email" class="form-control">
                                </div>
                            </div>

                            <div class="mb-3">
                                <label>Message</label>
                                <textarea class="form-control" rows="4"></textarea>
                            </div>

                            <button class="btn btn-primary">Send Message</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php get_footer(); ?>