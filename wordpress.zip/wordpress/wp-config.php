<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the website, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'modest_db' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '_mIkN(tjzSvs!@`r&t$Z)G!VznTcc>r8X:T0YP<J{^KB}s5(,]2c_a(M#^xp$_<r' );
define( 'SECURE_AUTH_KEY',  'N# LMHQR^V7%xCn$}VmvA{ncjEx3KOn]jc38IX!s,=pa<GMS(sRyF)sUq%*<O!JJ' );
define( 'LOGGED_IN_KEY',    'rK3n j2)v/QFRfR!L]_=)3sz~wm50w{s6<wCF{V~(@oHHD{t[:ok=d]{#lgdq4L>' );
define( 'NONCE_KEY',        '8D9JR2^z=_c`a*`.]3Eh=Sd;w|H:#Mv8F<7;N]+P`U17aH_ YiPmvIPxJge4o~}B' );
define( 'AUTH_SALT',        '#&YMl7 pt9%%.2?Q$VC}$<ms2tE[zJ:4OMvsQ]chvako}e_r5TogPv2[4jQvo_$_' );
define( 'SECURE_AUTH_SALT', 'fao.<S4z*O&Z~3x2GCEcaEg]XUEiAx6<VZJq8{g%W,+0(PP9gR#[bI$m#Y&-dszo' );
define( 'LOGGED_IN_SALT',   'm6,k ~)2FA!_tIem;wk{@>L^4xq82`t^/3^4QW^tx{{wBXMCN$F5vf/|c?-`5G}x' );
define( 'NONCE_SALT',       'f).U}B7<x{3rk-2LI>Z,xi(]Rf`<pbyq}1K]49b~?t+8pBOh,]qAUa.:bx-.5juh' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 *
 * At the installation time, database tables are created with the specified prefix.
 * Changing this value after WordPress is installed will make your site think
 * it has not been installed.
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/#table-prefix
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://developer.wordpress.org/advanced-administration/debug/debug-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
